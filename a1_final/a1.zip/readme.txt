Nicholas Alderman - 20060982 - 16NAA5

Code works as described; left click and drag to change brightess and contrast, right click and drag to scale image, 'h' to preform local histogram equalization. Test feature: rotate the image by typing 'r' (only workes with square images)